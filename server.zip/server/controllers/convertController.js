import Unit from "../models/Unit.js";

/**
 * POST /convert
 * Nhận địa chỉ 3 cấp -> Trả về dạng chuẩn hóa từ MongoDB
 */
export async function convertAddress(req, res) {
  try {
    const { address } = req.body;
    if (!address) {
      return res.status(400).json({ error: "Thiếu địa chỉ cần chuyển đổi" });
    }

    // 🧩 Chuẩn hóa và tách địa chỉ thành các phần
    const parts = address.split(",").map(p => p.trim());
    if (parts.length < 3) {
      return res.status(400).json({ error: "Địa chỉ phải có ít nhất 3 cấp (Tỉnh, Huyện, Xã)" });
    }

    const [provinceName, districtName, communeName] = parts;

    // 🧠 Sử dụng Regex không phân biệt hoa/thường & có thể match một phần
    const province = await Unit.findOne({
      name: { $regex: provinceName.replace(/Tỉnh|Thành phố/gi, "").trim(), $options: "i" },
      level: "province",
    });

    const district = await Unit.findOne({
      name: { $regex: districtName.replace(/Huyện|Quận|Thị xã|Thành phố/gi, "").trim(), $options: "i" },
      level: "district",
    });

    const commune = await Unit.findOne({
      name: { $regex: communeName.replace(/Xã|Phường|Thị trấn/gi, "").trim(), $options: "i" },
      level: "commune",
    });

    // 🧾 Trả về kết quả
    res.json({
      original: address,
      matched: {
        province: province?.name || null,
        district: district?.name || null,
        commune: commune?.name || null,
      },
      codes: {
        province: province?.code || null,
        district: district?.code || null,
        commune: commune?.code || null,
      },
      found: !!(province || district || commune),
    });
  } catch (err) {
    console.error("❌ Convert Error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
}
