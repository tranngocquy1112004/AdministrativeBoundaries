import fs from "fs";
import path from "path";
import { buildTree } from "../utils/finder.js";
// ✅ Đường dẫn dữ liệu
const dataPath = path.resolve("server/data/units.json");

/**
 * Đọc dữ liệu JSON từ file
 */
function readData() {
  try {
    if (!fs.existsSync(dataPath)) return [];
    const fileContent = fs.readFileSync(dataPath, "utf8");
    return JSON.parse(fileContent || "[]");
  } catch (err) {
    console.error("❌ Error reading units.json:", err);
    return [];
  }
}

/**
 * Ghi dữ liệu vào file JSON
 */
function writeData(data) {
  try {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2), "utf8");
  } catch (err) {
    console.error("❌ Error writing to units.json:", err);
  }
}

/**
 * ✅ GET /units - Lấy toàn bộ danh sách đơn vị hành chính
 */
export function getUnits(req, res) {
  const data = readData();
  res.json(data);
}

/**
 * ✅ POST /units - Tạo mới một đơn vị hành chính
 */
export function createUnit(req, res) {
  try {
    const { name, code, level, parentCode, boundary } = req.body;

    if (!name || !code || !level) {
      return res.status(400).json({ error: "Thiếu các trường bắt buộc (name, code, level)" });
    }

    const data = readData();
    const exists = data.find((u) => u.code === code);
    if (exists) {
      return res.status(400).json({ error: `Mã đơn vị '${code}' đã tồn tại` });
    }

    const newUnit = {
      id: Date.now(),
      name,
      code,
      level,
      parentCode: parentCode || null,
      boundary: boundary || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      history: [],
      children: [],
    };

    data.push(newUnit);
    writeData(data);

    res.status(201).json({
      message: "✅ Thêm mới đơn vị hành chính thành công",
      unit: newUnit,
    });
  } catch (err) {
    console.error("❌ Error creating unit:", err);
    res.status(500).json({ error: "Lỗi máy chủ khi tạo đơn vị hành chính" });
  }
}

/**
 * ✅ PUT /units/:id - Cập nhật thông tin đơn vị hành chính
 */
export function updateUnit(req, res) {
  try {
    const { id } = req.params;
    const data = readData();
    const index = data.findIndex((u) => String(u.id) === String(id));

    if (index === -1) {
      return res.status(404).json({ error: "Không tìm thấy đơn vị hành chính" });
    }

    const oldUnit = { ...data[index] };
    const updatedUnit = {
      ...oldUnit,
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    // ✅ Lưu phiên bản cũ vào lịch sử
    updatedUnit.history = [...(oldUnit.history || []), oldUnit];

    data[index] = updatedUnit;
    writeData(data);

    res.json({
      message: "✅ Cập nhật đơn vị hành chính thành công",
      unit: updatedUnit,
    });
  } catch (err) {
    console.error("❌ Error updating unit:", err);
    res.status(500).json({ error: "Lỗi máy chủ khi cập nhật" });
  }
}

/**
 * ✅ DELETE /units/:id - Xóa đơn vị hành chính
 */
export function deleteUnit(req, res) {
  try {
    const { id } = req.params;
    let data = readData();

    const exists = data.find((u) => String(u.id) === String(id));
    if (!exists) {
      return res.status(404).json({ error: "Unit not found" });
    }

    data = data.filter((u) => String(u.id) !== String(id));
    writeData(data);

    res.json({ message: "✅ Xóa đơn vị hành chính thành công" });
  } catch (err) {
    console.error("❌ Error deleting unit:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
}

/**
 * ✅ GET /units/:id/history - Lấy lịch sử thay đổi của một đơn vị
 */
export function getHistory(req, res) {
  const { id } = req.params;
  const data = readData();
  const unit = data.find((u) => String(u.id) === String(id));

  if (!unit) {
    return res.status(404).json({ error: "Không tìm thấy đơn vị hành chính" });
  }

  res.json(unit.history || []);
}

/**
 * ✅ POST /units/:id/restore - Khôi phục đơn vị từ lịch sử
 */
export function restoreFromHistory(req, res) {
  try {
    const { id } = req.params;
    const { index } = req.body;
    const data = readData();

    const unit = data.find((u) => String(u.id) === String(id));
    if (!unit) {
      return res.status(404).json({ error: "Unit not found" });
    }

    const version = unit.history?.[index];
    if (!version) {
      return res.status(400).json({ error: "Invalid history index" });
    }

    Object.assign(unit, version);
    unit.updatedAt = new Date().toISOString();

    writeData(data);
    res.json({
      message: "✅ Khôi phục phiên bản thành công",
      unit,
    });
  } catch (err) {
    console.error("❌ Error restoring unit:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
}

/**
 * ✅ GET /units/search?name=...&code=...&level=...
 * Tra cứu đơn vị hành chính
 */
export function searchUnits(req, res) {
  try {
    const { name, code, level } = req.query;
    const data = readData();

    let result = data;

    if (name) {
      result = result.filter((u) =>
        u.name.toLowerCase().includes(name.toLowerCase())
      );
    }
    if (code) {
      result = result.filter((u) => String(u.code) === String(code));
    }
    if (level) {
      result = result.filter((u) => u.level === level);
    }

    if (result.length === 0) {
      return res.status(404).json({ message: "❌ Không tìm thấy đơn vị phù hợp." });
    }

    res.json(result);
  } catch (err) {
    console.error("❌ Lỗi searchUnits:", err);
    res.status(500).json({ error: "Lỗi khi tra cứu đơn vị hành chính." });
  }
}

/**
 * ✅ GET /units/tree - Xây cây phân cấp hành chính
 */
export function getUnitsTree(req, res) {
  const data = readData();
  const tree = buildTree(data);
  res.json(tree);
}

/**
 * ✅ GET /units/:id/diff?old=0&new=1 - So sánh sự thay đổi giữa hai phiên bản
 */
export function diffHistory(req, res) {
  const { id } = req.params;
  const { old, new: newer } = req.query;
  const data = readData();
  const unit = data.find((u) => String(u.id) === String(id));

  if (!unit) {
    return res.status(404).json({ error: "Không tìm thấy đơn vị" });
  }

  const a = unit.history?.[old];
  const b = unit.history?.[newer] || unit;

  if (!a || !b) {
    return res.status(400).json({ error: "Chỉ số lịch sử không hợp lệ" });
  }

  const diff = {};
  for (const key of Object.keys(b)) {
    if (JSON.stringify(a[key]) !== JSON.stringify(b[key])) {
      diff[key] = { old: a[key], new: b[key] };
    }
  }

  res.json(diff);
}
