import express from "express";
import {
  getUnits,
  createUnit,
  updateUnit,
  deleteUnit,
  getHistory,
  restoreFromHistory,
  searchUnits,
  getUnitsTree,
  diffHistory
} from "../controllers/unitController.js";
import validateUnit from "../middleware/validateUnit.js";

const router = express.Router();

// ✅ GET toàn bộ đơn vị hành chính
router.get("/", getUnits);

// ✅ GET chi tiết 1 đơn vị
router.get("/:id", getUnitById);

// ✅ POST - thêm mới
router.post("/", createUnit);

// ✅ PUT - cập nhật theo ID
router.put("/:id", updateUnit);

// ✅ PATCH - cập nhật nhanh (nếu có)
router.patch("/:id", updateUnit);

// ✅ DELETE - xóa theo ID
router.delete("/:id", deleteUnit);

// ✅ Lấy lịch sử
router.get("/:id/history", getHistory);

// ✅ Khôi phục từ lịch sử
router.post("/:id/restore", restoreFromHistory);

// ✅ Tìm kiếm
router.get("/search", searchUnits);

// ✅ Cây phân cấp hành chính
router.get("/tree", getUnitsTree);

// ✅ So sánh lịch sử
router.get("/:id/diff", diffHistory);

export default router;
