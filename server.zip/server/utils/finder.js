export function buildTree(units) {
  const map = new Map();

  // Tạo bản đồ lưu các đơn vị
  units.forEach(u => {
    map.set(u.code, { ...u, children: [] });
  });

  const tree = [];

  // Xây dựng quan hệ cha - con
  map.forEach(u => {
    if (u.parentCode && map.has(u.parentCode)) {
      map.get(u.parentCode).children.push(u);
    } else {
      tree.push(u);
    }
  });

  return tree;
}
